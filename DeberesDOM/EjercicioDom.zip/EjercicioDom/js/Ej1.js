let inventario = [
  { nombre: "Manzanas", cantidad: 10, precio: 1.5 },
  { nombre: "Naranjas", cantidad: 20, precio: 2.0 },
  { nombre: "Plátanos", cantidad: 15, precio: 1.2 },
  { nombre: "Peras", cantidad: 5, precio: 2.5 }
];


document.addEventListener("DOMContentLoaded", () => {
  const tabla = document.getElementById('inventario');

  function crearFila(item) {
    const fila = document.createElement('tr');

    const celdaNombre = document.createElement('td');
    celdaNombre.textContent = item.nombre;
    fila.appendChild(celdaNombre);

    const celdaCantidad = document.createElement('td');
    celdaCantidad.textContent = item.cantidad;
    fila.appendChild(celdaCantidad);

    const celdaPrecio = document.createElement('td');
    celdaPrecio.textContent = item.precio;
    fila.appendChild(celdaPrecio);

    const celdaEliminar = document.createElement('td');
    const btnEliminar = document.createElement('button');
    btnEliminar.textContent = "Eliminar";
    celdaEliminar.appendChild(btnEliminar);
    fila.appendChild(celdaEliminar);

    btnEliminar.addEventListener("click", () => {
      // Eliminar del DOM
      tabla.removeChild(fila);
      // Eliminar del array
      const index = inventario.indexOf(item);
      if (index != -1) {
        inventario.splice(index);
      }
    });

    tabla.appendChild(fila);
  }

  // Cargar inventario inicial
  inventario.forEach(item => crearFila(item));

  let annadir = document.getElementById("annadir");
  annadir.addEventListener("click", annadirArticulos);

  function annadirArticulos() {
    let nombre = document.getElementById("nombre").value;
    let cantidad = document.getElementById("cantidad").value;
    let precio = document.getElementById("precio").value;

    const nuevoItem = { nombre, cantidad, precio };
    inventario.push(nuevoItem);
    crearFila(nuevoItem);

    document.getElementById("nombre").value = "";
    document.getElementById("cantidad").value = "";
    document.getElementById("precio").value = "";
  }
});